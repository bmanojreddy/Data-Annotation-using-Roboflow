# License Plate > 2025-05-14 10:32am
https://universe.roboflow.com/license-plate-lut9m/license-plate-rm8zb

Provided by a Roboflow user
License: CC BY 4.0

